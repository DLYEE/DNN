1. environment: python
2. used library: theano, numpy, random, re, time, cPickle
3. 可調參數： (1)rnnClass.py line 64: 要clip的大小
	    (2)rnnTrainFunc.py line 9: sequence的大小
	    (3)rnnTrainFunc.py line 48: neuron numbers
	    (4)rnnTrainFunc.py line 52: learning rate
	    (5)rnnTrainFunc.py line 92: NAG中的lambda
4. usage:
	(1)python
	(2)import rnnMain
	(3)rnnMain.readTrain() (吃training input data)
	   (line 16: readPickle的第一個argument是label, 第二個是training data)
	   (line 17: readLabel的argument是label)
	(4)rnnMain.train(epochNum)
	   (epochNum為要跑epoch的次數)
	(5)觀察cost, gradient，決定要不要繼續train
	(6)rnnMain.readTest() (吃test input data)
	   (line 26: readPickleTest的第一個argument是mfcc的test.ark(用來讀取frame的名字), 第二個是testing data 1, 第三個是testing data 2(因為我們把testing data拆成兩個部份壓縮))
	(7)rnnMain.test()
	   (line 47: writeFile的第一個argument為要輸出成還沒trim前.csv檔的檔名)
	   (line 48: trimOutput的第一個argument為還沒trim前.csv檔的檔名, 第二個argument為trim後.csv檔的檔名)
